# -*- coding: utf-8 -*-

from odoo import models, fields, api, _, tools
from odoo.exceptions import UserError, ValidationError
from dateutil import parser

class Partner(models.Model):
    _inherit = 'res.partner'

    jns_pengguna = fields.Selection([
	    	('penyetor', 'PENYETOR'), 
	    	('pengambil', 'PENGAMBIL'),
	    	('none', 'NONE')
	    ], 
	    string="Jenis Pengguna", 
	    default='penyetor'
    )

    has_kontrak = fields.Boolean(
    	string="Already have a contract",
    	default=False
    )

    kontrak_pengambil_ids = fields.One2many(
    	'kontrak.pengambil',
    	'contact_id', 
    	string="Kontrak dengan Pengambil"
    )

    @api.depends('kontrak_pengambil_ids')
    def getlenjadwal(self):
    	for line in self:
    		line.lenjadwal = len(line.kontrak_pengambil_ids.ids)

    lenjadwal = fields.Integer(
    	compute='getlenjadwal'
    )

    def action_jadwal(self):
    	view_id = self.env.ref("waste__management__biomag.jadwal_pengambilan_tree").id
    	result = {
    		"name": 'Jadwal Pengambilan',
    		"type": 'ir.actions.act_window',
    		"views": [[view_id, "tree"]],
    		"res_model": 'jadwal.pengambilan',
    		"view_id": view_id,
    		"domain": [('partner_penyetor', '=', self.id)]
    	}
    	return result

    def action_setor(self):
    	view_id = self.env.ref("waste__management__biomag.setor_tree").id
    	result = {
    		"name": 'Penyetoran Sampah',
    		"type": 'ir.actions.act_window',
    		"views": [[view_id, "tree"]],
    		"res_model": 'setor.setor',
    		"view_id": view_id,
    		"domain": [('partner_penyetor', '=', self.id)]
    	}
    	return result

    def action_ambil(self):
    	view_id = self.env.ref("waste__management__biomag.ambil_tree").id
    	result = {
    		"name": 'Pengambilan Sampah',
    		"type": 'ir.actions.act_window',
    		"views": [[view_id, "tree"]],
    		"res_model": 'ambil.ambil',
    		"view_id": view_id,
    		"domain": [('partner_pengambil', '=', self.id)]
    	}
    	return result

class KontrakPengambil(models.Model):
    _name = 'kontrak.pengambil'
    _description = 'Kontrak Penyetor dengan Pengambil'

    contact_id = fields.Many2one(
        'res.partner',
        string='contact_id',
    )

    partner_pengambil = fields.Many2one(
    	'res.partner', 
    	string="Pengambil", 
    	domain=[('jns_pengguna', '=', 'pengambil'), ('active', '=', True)]
    )

    mobile = fields.Char(string="No HP", related='partner_pengambil.mobile')

    upload_file = fields.Binary(string="Upload File")
    file_name = fields.Char(string="File Name")
    
class JadwalPengambilan(models.Model):
    _name = 'jadwal.pengambilan'
    _inherit = ['mail.thread']
    _description = 'Jadwal Pengambilan'
    _sql_constraints = [
        ('name', 'unique(name)', 'No.Jadwal already exist !')
    ]

    name = fields.Char(
        default=lambda self: _('New'),
        copy=False,
        index=True,
        readonly=True,
        ondelete="restrict",
        string='No.Jadwal'
    )

    tgl1 = fields.Date('Periode Awal', default=fields.Datetime.now, track_visibility='onchange')
    tgl2 = fields.Date('Periode Akhir', default=fields.Datetime.now, track_visibility='onchange')

    partner_penyetor = fields.Many2one(
    	'res.partner', 
    	st="Penyetor", 
    	domain=[('jns_pengguna', '=', 'penyetor'), ('active', '=', True)],
    	track_visibility='onchange'
    )

    partner_company = fields.Many2one(
    	'res.partner', 
    	st="Company/UMKM", 
    	related='partner_penyetor.parent_id',
    	track_visibility='onchange'
    )

    jenis_sampah = fields.Selection([
	    	('organik', 'ORGANIK'), 
	    	('anorganik', 'AN-ORGANIK')
	    ], 
	    string="Jenis Sampah", 
	    default='organik',
	    track_visibility='onchange'
    )

    partner_pengambil = fields.Many2one(
    	'res.partner', 
    	st="Pengambil", 
    	domain=[('jns_pengguna', '=', 'pengambil'), ('active', '=', True)],
    	track_visibility='onchange'
    )

    description = fields.Text(string='Keterangan', track_visibility='onchange')

    @api.onchange('partner_penyetor')
    def change_pengguna_id(self):
    	self.partner_pengambil = False
    	res = {'domain': {'partner_pengambil': [('jns_pengguna', '=', 'pengambil')]}}
    	if self.partner_penyetor:
    		pengambil_ids = []
    		for line in self.partner_penyetor.kontrak_pengambil_ids:
    			pengambil_ids.append(line.partner_pengambil.id)
    		res['domain'] = {'partner_pengambil': [('id', 'in', pengambil_ids)]}
    	return res

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'jadwal.pengambilan.number_sequence') or _('New')
        result = super(JadwalPengambilan, self).create(vals)
        return result

    jadwal_det = fields.One2many(
        'jadwal.pengambilan_det',
        'jadwal_id', 
        string="Detail Jadwal"
    )

class JadwalPengambilanDet(models.Model):
    _name = 'jadwal.pengambilan_det'
    _description = 'Detail Jadwal Pengambilan'

    jadwal_id = fields.Many2one(
        'jadwal.pengambilan',
        string='jadwal_id',
    )

    hari = fields.Selection( 
        [('senin', 'Senin'), ('selasa', 'Selasa'), ('rabu', 'Rabu'), ('kamis', 'Kamis'), ('jumat', 'Jumat'), ('sabtu', 'Sabtu'), ('minggu', 'Minggu')],
        string='Hari',
    )

    jam = fields.Float(string='Jam')

class Setor(models.Model):
    _name = 'setor.setor'
    _inherit = ['mail.thread']
    _description = 'Setoran Sampah'
    _sql_constraints = [
        ('name', 'unique(name)', 'No.Penyetoran already exist !')
    ]

    name = fields.Char(
        default=lambda self: _('New'),
        copy=False,
        index=True,
        readonly=True,
        ondelete="restrict",
        string='No.Penyetoran'
    )

    tanggal = fields.Date('Tanggal', default=fields.Datetime.now, track_visibility='onchange')

    def get_iddefault(self):
    	iddefault = False
    	if self.env.user.partner_id.jns_pengguna == 'penyetor':
    		iddefault = self.env.user.partner_id.id
    	return iddefault

    partner_penyetor = fields.Many2one(
    	'res.partner', 
    	string="Penyetor", 
    	default=get_iddefault,
    	domain=[('jns_pengguna', '=', 'penyetor'), ('active', '=', True)],
    	track_visibility='onchange'
    )

    partner_pengambil = fields.Many2one(
    	'res.partner', 
    	string="Pengambil", 
    	domain=[('jns_pengguna', '=', 'pengambil'), ('active', '=', True)],
    	track_visibility='onchange'
    )

    @api.onchange('partner_penyetor')
    def change_pengguna_id(self):
    	self.partner_pengambil = False
    	res = {'domain': {'partner_pengambil': [('jns_pengguna', '=', 'pengambil')]}}
    	if self.partner_penyetor:
    		pengambil_ids = []
    		for line in self.partner_penyetor.kontrak_pengambil_ids:
    			pengambil_ids.append(line.partner_pengambil.id)
    		res['domain'] = {'partner_pengambil': [('id', 'in', pengambil_ids)]}
    	return res

    mtd_pengambilan = fields.Selection(
    	[('diambil', 'DIAMBIL'), ('diantar', 'DIANTAR')], 
    	string="metode pengambilan",
    	default='diambil',
    	track_visibility='onchange'
    )

    jenis_sampah = fields.Selection([
	    	('organik', 'ORGANIK'), 
	    	('anorganik', 'AN-ORGANIK')
	    ], 
	    string="Jenis Sampah", 
	    default='organik',
	    track_visibility='onchange'
    )

    state = fields.Selection(
    	[('draft', 'Draft'), ('ready', 'Ready'), ('proses', 'Proses'), ('sukses', 'Sukses'), ('cancel', 'Cancel')], 
    	string="status", 
    	default='draft',
    	track_visibility='onchange'
    )

    partner_sampah = fields.Many2one(
    	'res.partner', 
    	string="Company/UMKM", 
    	domain=[('active', '=', True)],
    	track_visibility='onchange'
    )

    partner_sampah_mobile = fields.Char(related='partner_sampah.mobile', string="Mobile")
    partner_sampah_street = fields.Char(related='partner_sampah.street')
    partner_sampah_street2 = fields.Char(related='partner_sampah.street2')
    partner_sampah_zip = fields.Char(related='partner_sampah.zip')
    partner_sampah_city = fields.Char(related='partner_sampah.city')
    partner_sampah_state_id = fields.Many2one("res.country.state", string='Provinsi', related='partner_sampah.state_id')
    partner_sampah_country_id = fields.Many2one('res.country', string='Negara', related='partner_sampah.country_id')

    tgl_ambil = fields.Datetime('Tanggal Ambil', track_visibility='onchange')
    description = fields.Text(string='Keterangan', track_visibility='onchange')

    sampah_nama = fields.Char(string="Nama Sampah")
    sampah_berat = fields.Float(string="Berat")
    sampah_harga = fields.Float(string="Amount")
    sampah_satuan = fields.Selection([
	    	('Kg', 'Kg'), 
	    	('Gram', 'Gram'),
	    	('Liter', 'Liter')
	    ], 
	    string="Satuan", 
	    default='Kg',
	    track_visibility='onchange'
    )

    dari = fields.Char()

    def action_draft(self):
    	self.write({'state': 'draft', 'dari': 'dari'})

    def action_confirm(self):
    	self.write({'state': 'ready', 'dari': 'dari'})

    def action_cancel(self):
    	self.write({'state': 'cancel', 'dari': 'dari'})

    def action_ambil(self):
    	view_id = self.env.ref("waste__management__biomag.ambil_form").id
    	result = {
    		"name": 'Pengambilan Sampah',
    		"type": 'ir.actions.act_window',
    		"views": [[view_id, "form"]],
    		"res_model": 'ambil.ambil',
    		"view_id": view_id,
    		"context": {
                'default_partner_pengambil': self.partner_pengambil.id,
                'default_no_penyetoran': self.id,
            }
    	}
    	return result

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'setor.setor.number_sequence') or _('New')
        result = super(Setor, self).create(vals)
        return result

    def write(self, vals):
        if self.state != "draft":
        	if 'dari' not in vals:
        		raise ValidationError(_('Hanya DRAFT state bisa UPDATE.'))
        res = super(Setor, self).write(vals)
        return res

    def unlink(self):
        for record in self:
            if record.state != "cancel":
                raise ValidationError(_('Only CANCEL state can DELETE.'))
        return super(Setor, self).unlink()

    def _autocancel(self):
        datasetor = self.env['setor.setor'].search([('state', 'in', ['draft', 'ready'])])
        minutes_cancel = 1440
        minutes_config = self.env["ir.config_parameter"].search([("key", "=", "limit_cancel")])
        if minutes_config:
            minutes_cancel = minutes_config.value
        for line in datasetor:
            nownya = fields.datetime.now()
            diff = nownya - line.create_date
            minutes = diff.total_seconds() / 60
            if minutes > int(minutes_cancel):
                line.write({'state': 'cancel', 'dari': 'dari'})

class Ambil(models.Model):
    _name = 'ambil.ambil'
    _inherit = ['mail.thread']
    _description = 'Pengambilan Sampah'
    _sql_constraints = [
        ('name', 'unique(name)', 'No.Setor already exist !')
    ]

    name = fields.Char(
        default=lambda self: _('New'),
        copy=False,
        index=True,
        readonly=True,
        ondelete="restrict",
        string='No.Pengambilan'
    )

    tanggal = fields.Date('Tanggal', default=fields.Datetime.now, track_visibility='onchange')

    def get_iddefault(self):
    	iddefault = False
    	if self.env.user.partner_id.jns_pengguna == 'pengambil':
    		iddefault = self.env.user.partner_id.id
    	return iddefault

    partner_pengambil = fields.Many2one(
    	'res.partner', 
    	string="Pengambil", 
    	default=get_iddefault,
    	domain=[('jns_pengguna', '=', 'pengambil'), ('active', '=', True)],
    	track_visibility='onchange'
    )

    no_penyetoran = fields.Many2one(
    	'setor.setor', 
    	string="No.Penyetoran", 
    	domain=[('state', '=', 'ready')],
    	track_visibility='onchange'
    )

    @api.depends('no_penyetoran')
    def getdatasetor(self):
        for line in self:
            line.jenis_sampah = line.no_penyetoran.jenis_sampah
            line.sampah_nama = line.no_penyetoran.sampah_nama
            line.sampah_berat = line.no_penyetoran.sampah_berat
            line.sampah_satuan = line.no_penyetoran.sampah_satuan
            line.description_setor = line.no_penyetoran.description

    # def pro_search_jenis_sampah(self, operator, value):
    #     if operator == 'like':
    #         operator = 'ilike'
    #     return [('no_penyetoran.jenis_sampah', operator, value)]

    description_setor = fields.Text(string='Deskripsi Penyetoran', compute='getdatasetor', store=False)

    jenis_sampah = fields.Selection([
            ('organik', 'ORGANIK'), 
            ('anorganik', 'AN-ORGANIK')
        ], 
        string="Jenis Sampah",
        store=True,
        compute='getdatasetor',
        # search=pro_search_jenis_sampah
    )

    # def pro_search_sampah_nama(self, operator, value):
    #     if operator == 'like':
    #         operator = 'ilike'
    #     return [('no_penyetoran.sampah_nama', operator, value)]

    sampah_nama = fields.Char(
        string="Nama Sampah",
        store=True,
        compute='getdatasetor',
        # search=pro_search_sampah_nama
    )

    # def pro_search_sampah_berat(self, operator, value):
    #     if operator == 'like':
    #         operator = 'ilike'
    #     return [('no_penyetoran.sampah_berat', operator, value)]

    sampah_berat = fields.Float(string="Berat", 
        store=True,
        compute='getdatasetor',
        # search=pro_search_sampah_berat
    )

    # def pro_search_sampah_satuan(self, operator, value):
    #     if operator == 'like':
    #         operator = 'ilike'
    #     return [('no_penyetoran.sampah_satuan', operator, value)]

    sampah_satuan = fields.Selection([
            ('Kg', 'Kg'), 
            ('Gram', 'Gram'),
            ('Liter', 'Liter')
        ], 
        string="Satuan",
        store=True,
        compute='getdatasetor',
        # search=pro_search_sampah_satuan
    )

    @api.onchange('partner_pengambil')
    def change_partner_pengambil(self):
    	res = {'domain': {'no_penyetoran': [('state', '=', 'ready')]}}
    	if self.partner_pengambil:
    		res['domain'] = {'no_penyetoran': [('state', '=', 'ready'), ('partner_pengambil', '=', self.partner_pengambil.id)]}
    	return res

    @api.onchange('no_penyetoran')
    def change_no_penyetoran(self):
    	if self.no_penyetoran:
    		self.sampah_harga = self.no_penyetoran.sampah_harga

    partner_sampah = fields.Many2one(
    	'res.partner', 
    	string="Company/UMKM",
    	related='no_penyetoran.partner_sampah',
    )

    partner_sampah_mobile = fields.Char(related='no_penyetoran.partner_sampah_mobile', string="Mobile")
    partner_sampah_street = fields.Char(related='no_penyetoran.partner_sampah_street')
    partner_sampah_street2 = fields.Char(related='no_penyetoran.partner_sampah_street2')
    partner_sampah_zip = fields.Char(related='no_penyetoran.partner_sampah_zip')
    partner_sampah_city = fields.Char(related='no_penyetoran.partner_sampah_city')
    partner_sampah_state_id = fields.Many2one("res.country.state", string='Provinsi', related='no_penyetoran.partner_sampah_state_id')
    partner_sampah_country_id = fields.Many2one('res.country', string='Negara', related='no_penyetoran.partner_sampah_country_id')

    mtd_pengambilan = fields.Selection(
    	[('diambil', 'DIAMBIL'), ('diantar', 'DIANTAR')], 
    	string="metode pengambilan",
    	related='no_penyetoran.mtd_pengambilan'
    )

    state = fields.Selection(
    	[('ready', 'Ready'), ('proses', 'Proses'), ('sukses', 'Sukses'), ('cancel', 'Cancel')], 
    	string="status", 
    	default='ready',
    	track_visibility='onchange'
    )

    sampah_harga = fields.Float(string="Amount")
    description = fields.Text(string='Keterangan', track_visibility='onchange')

    dari = fields.Char()

    def action_sukses(self):
    	self.write({'state': 'sukses', 'dari': 'dari'})
    	self.no_penyetoran.write({'state': 'sukses', 'dari': 'dari'})

    def action_confirm(self):
    	self.write({'state': 'proses', 'dari': 'dari'})

    def action_cancel(self):
    	self.write({'state': 'cancel', 'dari': 'dari'})

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'ambil.ambil.number_sequence') or _('New')
        result = super(Ambil, self).create(vals)
        result.no_penyetoran.write({'state': 'proses', 'tgl_ambil': fields.datetime.now(), 'dari': 'dari'})
        return result

    def write(self, vals):
        if self.state != "ready":
        	if 'dari' not in vals:
        		raise ValidationError(_('Hanya READY state bisa UPDATE.'))
        res = super(Ambil, self).write(vals)
        return res

    def unlink(self):
        for record in self:
            if record.state != "cancel":
                raise ValidationError(_('Only CANCEL state can DELETE.'))
            record.no_penyetoran.write({'state': 'ready', 'tgl_ambil': False, 'dari': 'dari'})
        return super(Ambil, self).unlink()

    def _autoambil(self):
        today_date = fields.datetime.now().strftime("%Y-%m-%d")
        # now_hour = fields.datetime.now().strftime("%H")
        now_hour = int(fields.datetime.now().strftime("%H")) + 7
        now_minute = int(fields.datetime.now().strftime("%M"))
        day_name = fields.datetime.now().strftime("%A")
        hari = [('senin', 'Senin'), ('selasa', 'Selasa'), ('rabu', 'Rabu'), ('kamis', 'Kamis'), ('jumat', 'Jumat'), ('sabtu', 'Sabtu'), ('minggu', 'Minggu')]
        day_name2 = day_name
        if day_name == 'Sunday':
            day_name2 = 'minggu'
        elif day_name == 'Monday':
            day_name2 = 'senin'
        elif day_name == 'Tuesday':
            day_name2 = 'selasa'
        elif day_name == 'Wednesday':
            day_name2 = 'rabu'
        elif day_name == 'Thursday':
            day_name2 = 'kamis'
        elif day_name == 'Friday':
            day_name2 = 'jumat'
        elif day_name == 'Saturday':
            day_name2 = 'sabtu'
        data_jadwal = self.env['jadwal.pengambilan'].search([
            ('tgl1', '<=', today_date),
            ('tgl2', '>=', today_date)
        ])

        date1 = parser.parse(fields.datetime.now().strftime("%Y-%m-%d " + str(now_hour) + ":" + str(now_minute)))
        for zz in data_jadwal:
            for line in zz.jadwal_det:
                if line.hari == day_name2:
                    jam_jadwal = '{0:02.0f}:{1:02.0f}'.format(*divmod(line.jam * 60, 60))
                    date2 = parser.parse(fields.datetime.now().strftime("%Y-%m-%d " + jam_jadwal))
                    minutes_diff = (date1 - date2).total_seconds() / 60.0
                    if int(minutes_diff) <= 11:
                        datasetor = self.env['setor.setor'].search([
                            ('state', '=', 'ready'),
                            ('partner_penyetor', '<=', zz.partner_penyetor.id),
                            ('partner_pengambil', '>=', zz.partner_pengambil.id)
                        ])
                        if datasetor:
                            for line2 in datasetor:
                                vals_ambil = {
                                    'state': 'ready', 
                                    'tanggal': today_date, 
                                    'partner_pengambil': line2.partner_pengambil.id, 
                                    'no_penyetoran': line2.id, 
                                    'sampah_harga': line2.sampah_harga, 
                                    'description': False, 
                                    'message_follower_ids': [], 
                                    'message_ids': []
                                }
                                addambil = self.env['ambil.ambil'].create(vals_ambil)
                                print('----------->> ', line2, addambil)
        
class Laporan(models.Model):
    _name = 'laporan.laporan'
    _description = 'Laporan Penyetoran & Pengambilan'
    _auto = False

    name = fields.Char(
        string='Nomor'
    )

    tanggal = fields.Date('Tanggal')

    partner_penyetor = fields.Many2one(
        'res.partner', 
        string="Penyetor"
    )

    partner_pengambil = fields.Many2one(
        'res.partner', 
        string="Pengambil"
    )

    mtd_pengambilan = fields.Selection(
        [('diambil', 'DIAMBIL'), ('diantar', 'DIANTAR')], 
        string="metode pengambilan"
    )

    jenis_sampah = fields.Selection([
            ('organik', 'ORGANIK'), 
            ('anorganik', 'AN-ORGANIK')
        ], 
        string="Jenis Sampah"
    )

    state = fields.Selection(
        [('draft', 'Draft'), ('ready', 'Ready'), ('proses', 'Proses'), ('sukses', 'Sukses'), ('cancel', 'Cancel')], 
        string="status"
    )

    partner_sampah = fields.Many2one(
        'res.partner', 
        string="Company/UMKM"
    )

    description = fields.Text(string='Keterangan', track_visibility='onchange')

    sampah_nama = fields.Char(string="Nama Sampah")
    sampah_berat = fields.Float(string="Berat")
    sampah_harga = fields.Float(string="Amount")
    sampah_satuan = fields.Selection([
            ('Kg', 'Kg'), 
            ('Gram', 'Gram'),
            ('Liter', 'Liter')
        ], 
        string="Satuan",
    )
    create_date = fields.Datetime('Create On')
    dari = fields.Char('Note')

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute('''
            CREATE OR REPLACE VIEW %s AS (
                SELECT (('100' || a.id::character varying)::bigint) as id, a.name, a.tanggal, a.partner_penyetor, a.partner_pengambil, 
                a.mtd_pengambilan, a.jenis_sampah, a.sampah_nama, a.sampah_berat, 
                a.sampah_harga, a.sampah_satuan, a.state, a.partner_sampah, a.description, a.create_date, 'PENYETORAN' as dari
                FROM setor_setor a 
                UNION ALL
                SELECT z.* FROM (
                    SELECT (('200' || b.id::character varying)::bigint) as id, b.name, b.tanggal, c.partner_penyetor, b.partner_pengambil, 
                    c.mtd_pengambilan, c.jenis_sampah, c.sampah_nama, c.sampah_berat, 
                    b.sampah_harga, c.sampah_satuan, b.state, c.partner_sampah, b.description, b.create_date, 'PENGAMBILAN' as dari
                    FROM ambil_ambil b 
                    INNER JOIN setor_setor c ON c.id = b.no_penyetoran
                )z
            )''' % (self._table,)
        )